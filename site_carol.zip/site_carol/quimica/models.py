from django.db import models

class Elemento(models.Model):
    simbolo = models.CharField("símbolo", max_length=2)
    nome = models.CharField(max_length = 15)
    peso = models.IntegerField("peso atômico")
