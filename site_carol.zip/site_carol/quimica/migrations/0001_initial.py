# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Elemento',
            fields=[
                ('id', models.AutoField(serialize=False, primary_key=True, verbose_name='ID', auto_created=True)),
                ('simbolo', models.CharField(max_length=2, verbose_name='símbolo')),
                ('nome', models.CharField(max_length=15)),
                ('peso', models.IntegerField(verbose_name='peso atômico')),
            ],
        ),
    ]
